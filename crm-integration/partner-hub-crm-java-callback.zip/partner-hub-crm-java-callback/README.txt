Partner Hub CRM 回调 — Java 自定义提交部署包
============================================

1. 部署 class（一次性）
   将 WEB-INF/classes/com/fr/data/PartnerHubLeadNotifyJob.class
   复制到帆软服务器 <FR_HOME>/WEB-INF/classes/com/fr/data/
   然后重启帆软报表服务。

2. 配置 CPT
   详见 docs/crm-java-custom-submit.md

3. 文件说明
   WEB-INF/classes/.../PartnerHubLeadNotifyJob.class  预编译，直接部署
   docs/crm-java-custom-submit.md                     完整操作手册
   source/                                            源码与 compile.sh（可选重编译）

Partner Hub 回调地址: https://camelusai.com/api/leads/crm-callback

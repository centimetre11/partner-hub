Partner Hub CRM 回调 — 设计器粘贴版
==================================

1. 打开 designer/PartnerHubLeadNotify.java，全文复制
2. 模板 → 报表填报属性 → 自定义提交 → 编辑 → 粘贴 → 编译 → 保存
3. 绑定 3 个属性：
   clueId(JobValue)=$clueid
   callbackSecret(String)=密钥
   action(String)=toNurture|toChannel|edit|toCustomer|shift
4. 删除旧 JS 回调，保存发布 CPT（无需重启服务器）

详见 docs/crm-migrate-js-to-java.md
